package com.belanjabot.app.ui.budget

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import com.belanjabot.app.util.EXPENSE_CATEGORIES
import com.belanjabot.app.util.catEmoji
import com.belanjabot.app.util.parseToCents

@Composable
fun NewBudgetDialog(existing: List<String>, onDismiss: () -> Unit, onSave: (String, Long) -> Unit) {
    var category by remember { mutableStateOf(EXPENSE_CATEGORIES.firstOrNull { !existing.contains(it.key) }?.key ?: "FOOD") }
    var amountText by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    val choices = EXPENSE_CATEGORIES.filter { !existing.contains(it.key) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                val cents = parseToCents(amountText)
                if (cents != null && choices.isNotEmpty()) onSave(category, cents)
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        title = { Text("New category budget") },
        text = {
            Column {
                Box {
                    OutlinedTextField(
                        value = choices.firstOrNull { it.key == category }?.let { "${it.emoji} ${it.label}" } ?: "Select",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Category") },
                        trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Box(Modifier.matchParentSize().clickable { menuOpen = true })
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        choices.forEach { c ->
                            DropdownMenuItem(text = { Text("${c.emoji} ${c.label}") }, onClick = { category = c.key; menuOpen = false })
                        }
                    }
                }
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Monthly limit") },
                    prefix = { Text("RM ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    )
}
