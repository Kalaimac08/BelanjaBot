package com.belanjabot.app.data

import android.content.Context
import androidx.room.Room
import com.belanjabot.app.data.db.AppDatabase

object Repository {
    @Volatile
    private var dbInstance: AppDatabase? = null

    /** First call must pass a Context (done from MainActivity). */
    fun db(context: Context? = null): AppDatabase {
        dbInstance?.let { return it }
        synchronized(this) {
            dbInstance?.let { return it }
            val ctx = requireNotNull(context?.applicationContext) { "Repository not initialised" }
            val d = Room.databaseBuilder(ctx, AppDatabase::class.java, "belanjabot.db")
                .fallbackToDestructiveMigration()
                .build()
            dbInstance = d
            return d
        }
    }
}
