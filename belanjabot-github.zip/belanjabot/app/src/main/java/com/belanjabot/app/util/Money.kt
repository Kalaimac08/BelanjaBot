package com.belanjabot.app.util

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

const val BUDGET_ALL = "ALL"

data class ExpCat(val key: String, val emoji: String, val label: String)

val EXPENSE_CATEGORIES = listOf(
    ExpCat("FOOD", "🍜", "Food & Drinks"),
    ExpCat("GROCERIES", "🛒", "Groceries"),
    ExpCat("TRANSPORT", "⛽", "Transport & Fuel"),
    ExpCat("BILLS", "💡", "Bills & Utilities"),
    ExpCat("SHOPPING", "🛍️", "Shopping"),
    ExpCat("HEALTH", "🏥", "Health"),
    ExpCat("EDUCATION", "📚", "Education"),
    ExpCat("FAMILY", "👨‍👩‍👧", "Kids & Family"),
    ExpCat("FUN", "🎬", "Entertainment"),
    ExpCat("TRAVEL", "✈️", "Travel"),
    ExpCat("OTHER", "📦", "Others")
)

fun catEmoji(key: String) = EXPENSE_CATEGORIES.firstOrNull { it.key == key }?.emoji ?: "📦"
fun catLabel(key: String) =
    if (key == BUDGET_ALL) "Overall" else EXPENSE_CATEGORIES.firstOrNull { it.key == key }?.label ?: key

fun formatRM(cents: Long): String {
    val abs = kotlin.math.abs(cents)
    val s = String.format(Locale.US, "%,.2f", abs / 100.0)
    return (if (cents < 0) "-RM " else "RM ") + s
}

/** Parse user text like "12.50" or "RM 1,234.56" to cents, or null if invalid. */
fun parseToCents(input: String): Long? {
    val cleaned = input.replace(",", "").replace("[^0-9.]".toRegex(), "")
    if (cleaned.isEmpty()) return null
    return try {
        BigDecimal(cleaned).multiply(BigDecimal(100)).setScale(0, RoundingMode.HALF_UP).longValueExact().takeIf { it >= 0 }
    } catch (e: Exception) {
        null
    }
}

val zone: ZoneId get() = ZoneId.systemDefault()

fun epochDayToMillis(epochDay: Long): Long =
    LocalDate.ofEpochDay(epochDay).atStartOfDay(ZoneId.of("UTC")).toInstant().toEpochMilli()

fun millisToEpochDay(millis: Long): Long =
    Instant.ofEpochMilli(millis).atZone(ZoneId.of("UTC")).toLocalDate().toEpochDay()

private val prettyDateFmt: DateTimeFormatter =
    DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.ENGLISH)

fun prettyDate(epochDay: Long): String = LocalDate.ofEpochDay(epochDay).format(prettyDateFmt)

fun monthLabel(ym: YearMonth): String =
    ym.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH))

fun yearBounds(year: Int): Pair<Long, Long> =
    LocalDate.of(year, 1, 1).toEpochDay() to LocalDate.of(year, 12, 31).toEpochDay()
