# 🇲🇾 Malaysia Personal Income Tax Relief — Reference for BelanjaBot

Relief categories tracked by the app, for **Year of Assessment (YA) 2025** (filed in 2026) and **YA 2026** (filing due 2027). Figures include changes announced in **Budget 2025** and **Budget 2026**. Always confirm on [hasil.gov.my](https://www.hasil.gov.my/en/individual/individual-life-cycle/income-declaration/tax-reliefs/) before filing.

## 🧾 Receipt-based reliefs (tracked in-app)

| # | Category | YA 2025 | YA 2026 | Notes |
|---|---|---|---|---|
| 1 | **Medical — serious disease & fertility** (self/spouse/child) | RM10,000* | RM10,000* | *shared RM10,000 medical cap for items 1–3 |
| 2 | **Medical check-up, vaccination, dental, mental health** | RM1,000 sub-limit | RM1,000 sub-limit | YA2026: vaccines expanded to all NPRA-registered |
| 3 | **Child learning-disability diagnosis & intervention** (≤18 yrs) | RM6,000 sub-limit | **RM10,000** sub-limit | Raised in Budget 2025 & 2026 |
| 4 | **EPF contributions** (mandatory + voluntary) | RM4,000 | RM4,000 | \ together capped at **RM7,000** |
| 5 | **Life insurance / family takaful** (own life) | RM3,000 | RM3,000 | / combined with EPF |
| 6 | **Parents' medical treatment, special needs & carer** | RM8,000 | RM8,000 | Since YA2025 includes **grandparents**; check-up sub-limit RM1,000 |
| 7 | **Basic supporting equipment** (disabled self/spouse/child/parent) | RM6,000 | RM6,000 | |
| 8 | **Education fees (self)** | RM7,000 | RM7,000 | Upskilling/self-enhancement sub-limit RM2,000 (extended to YA2026) |
| 9 | **Lifestyle** — books, PC/smartphone/tablet, internet, courses | RM2,500 | RM2,500 | |
| 10 | **Sports** — equipment, facilities, gym, competition fees | RM1,000 | RM1,000 | |
| 11 | **Breastfeeding equipment** (child ≤ 2 yrs) | RM1,000 | RM1,000 | Once every 2 YAs |
| 12 | **Childcare / kindergarten fees** (registered TASKA/TADIKA) | RM3,000 | RM3,000 | **YA2026: extended to care centres for kids up to 12** |
| 13 | **SSPN net deposit** | RM8,000 | RM8,000 | Extended to YA2027; either parent may claim |
| 14 | **Private Retirement Scheme & deferred annuity** | RM3,000 | RM3,000 | |
| 15 | **Education & medical insurance** | **RM4,000** | RM4,000 | ⬆️ Raised from RM3,000 in YA2025 |
| 16 | **SOCSO / EIS contributions** | RM350 | RM350 | |
| 17 | **EV charging & home green-tech** | RM2,500 | RM2,500 | YA2026–27: adds home food-waste grinders & CCTV (one purchase each) |
| 18 | **First-home loan interest** (new) | RM7,000 | RM7,000 | SPA 1/1/2025–31/12/2027, first 3 YAs. ≤RM500k: RM7,000; RM500k–750k: RM5,000 |
| 19 | **Tourist attractions & cultural programmes** (new) | — | **RM1,000** | YA2026 only |

## 🏠 Automatic reliefs (no receipts — reference list in app)

- Individual & dependent relatives — **RM9,000** (automatic)
- Spouse / alimony — up to **RM4,000**
- Disabled individual — **RM7,000** (⬆️ from RM6,000 in YA2025)
- Disabled spouse — **RM6,000** (⬆️ from RM5,000 in YA2025)
- Child < 18 — **RM2,000 each**; 18+ full-time education — RM2,000 (pre-U) / up to **RM8,000** (tertiary)
- Disabled child — **RM8,000** (⬆️ from RM6,000 in YA2025); +RM8,000 if in higher education

## 💰 Rebates (reduce tax payable directly)

- Zakat / fitrah / Islamic religious dues — actual amount paid
- Departure levy (umrah/pilgrimage, max 2 trips in a lifetime) — actual amount
- Chargeable income ≤ RM35,000 — **RM400** (RM800 jointly assessed)

## 📌 Golden rules

1. **Keep receipts for 7 years** — LHDN audits can reach that far back.
2. BelanjaBot applies **caps automatically** (per-category limits + combined caps for Medical RM10,000 and Life+EPF RM7,000).
3. Match the expense to the right relief *when you spend* — December panic-searching is how receipts get lost. 😉

*Sources: LHDN/BNM relief tables; Budget 2025 & Budget 2026 announcements (MOF, Bernama, The Edge); iMoney, SAYS, QuickHR, PwC summaries (2025–2026).*
