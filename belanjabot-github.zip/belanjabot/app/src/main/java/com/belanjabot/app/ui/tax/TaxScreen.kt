package com.belanjabot.app.ui.tax

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.belanjabot.app.data.Repository
import com.belanjabot.app.data.ReliefDef
import com.belanjabot.app.data.TaxReliefs
import com.belanjabot.app.data.db.ExpenseEntity
import com.belanjabot.app.ui.components.ExpenseListDialog
import com.belanjabot.app.ui.components.InfoNote
import com.belanjabot.app.ui.components.LimitProgress
import com.belanjabot.app.util.Export
import com.belanjabot.app.util.formatRM
import com.belanjabot.app.util.yearBounds
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

data class ReliefRowUi(val def: ReliefDef, val limit: Long, val used: Long) {
    val effective: Long get() = minOf(used, limit)
    val remaining: Long get() = (limit - used).coerceAtLeast(0)
}

data class ReliefGroupUi(val title: String, val cap: Long, val rows: List<ReliefRowUi>, val note: String) {
    val usedTotal: Long get() = rows.sumOf { it.used }
    val effectiveTotal: Long get() = minOf(rows.sumOf { it.effective }, cap)
}

data class TaxUi(
    val year: Int,
    val bracket: Int,
    val groups: List<ReliefGroupUi>,
    val singles: List<ReliefRowUi>,
    val totalClaimed: Long,
    val estSaved: Long,
    val expenses: List<ExpenseEntity>
)

class TaxViewModel : ViewModel() {
    private val db get() = Repository.db()
    val year = MutableStateFlow(LocalDate.now().year)
    val bracket = MutableStateFlow(11)

    @OptIn(ExperimentalCoroutinesApi::class)
    private val yearExpenses = year.flatMapLatest { y ->
        val (from, to) = yearBounds(y)
        db.expenseDao().between(from, to)
    }

    val ui: StateFlow<TaxUi> = combine(year, yearExpenses, bracket) { y, exp, b ->
        val usedByCode = exp.filter { it.taxReliefCode != null }
            .groupBy { it.taxReliefCode!! }
            .mapValues { (_, v) -> v.sumOf { it.amountCents } }

        val rows = TaxReliefs.forYear(y).map { r ->
            ReliefRowUi(r, r.limits[y]!!, usedByCode[r.code] ?: 0L)
        }
        val groups = TaxReliefs.groups.mapNotNull { g ->
            val cap = g.caps[y] ?: return@mapNotNull null
            val members = rows.filter { it.def.group == g.code }
            if (members.isEmpty()) null else ReliefGroupUi(g.title, cap, members, g.notes)
        }
        val singles = rows.filter { it.def.group == null }
        val total = groups.sumOf { it.effectiveTotal } + singles.sumOf { it.effective }
        TaxUi(y, b, groups, singles, total, total * b / 100, exp)
    }.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000),
        TaxUi(LocalDate.now().year, 11, emptyList(), emptyList(), 0, 0, emptyList())
    )
}

private val BRACKETS = listOf(3, 6, 11, 19, 25, 26, 30)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TaxScreen(onViewReceipt: (String) -> Unit, vm: TaxViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var detailFor by remember { mutableStateOf<ReliefRowUi?>(null) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(10.dp))
        Text("Malaysia Tax Relief 🧾", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TaxReliefs.YEARS.forEach { y ->
                FilterChip(selected = ui.year == y, onClick = { vm.year.value = y }, label = { Text("YA $y") })
            }
        }
        Spacer(Modifier.height(8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Total relief tracked (after caps)", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(4.dp))
                        Text(formatRM(ui.totalClaimed), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "≈ ${formatRM(ui.estSaved)} less tax at ${ui.bracket}% bracket",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(10.dp))
                        Text("Your tax bracket (top PCB/LHDN rate):", style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.height(6.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            BRACKETS.forEach { b ->
                                FilterChip(selected = ui.bracket == b, onClick = { vm.bracket.value = b }, label = { Text("$b%") })
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = {
                            scope.launch {
                                val f = Export.taxCsv(ctx, ui.year, ui.expenses)
                                Export.share(ctx, listOf(f), "Share tax relief summary")
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("📤 Export for e-Filing (CSV)") }
                    }
                }
            }

            ui.groups.forEach { g ->
                item(key = "g_${g.title}") {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text(g.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(g.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(8.dp))
                            LimitProgress(used = g.effectiveTotal, limit = g.cap)
                        }
                    }
                }
                items(g.rows, key = { it.def.code }) { row -> ReliefRowCard(row) { detailFor = row } }
            }

            item {
                Text("Other relief categories", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            items(ui.singles, key = { it.def.code }) { row -> ReliefRowCard(row) { detailFor = row } }

            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("ℹ️ Automatic reliefs (no receipts needed)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        TaxReliefs.automatic.forEach {
                            Text("• $it", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 2.dp))
                        }
                    }
                }
            }

            item {
                InfoNote(
                    "📌 Keep all receipts for 7 years — LHDN can ask for proof during an audit. " +
                        "This app is a tracking aid, not tax advice; verify figures on hasil.gov.my before filing."
                )
                Spacer(Modifier.height(90.dp))
            }
        }
    }

    detailFor?.let { row ->
        ExpenseListDialog(
            title = row.def.title,
            expenses = ui.expenses.filter { it.taxReliefCode == row.def.code },
            onOpenReceipt = onViewReceipt,
            onDismiss = { detailFor = null }
        )
    }
}

@Composable
private fun ReliefRowCard(row: ReliefRowUi, onClick: () -> Unit) {
    Card(onClick = onClick) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(row.def.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                if (row.used > 0) {
                    AssistChip(onClick = onClick, label = { Text("${if (row.remaining > 0) formatRM(row.remaining) + " left" else "maxed ✅"}") })
                }
            }
            Text(row.def.what, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (row.def.notes.isNotBlank()) {
                Text("⚠︎ ${row.def.notes}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            }
            Spacer(Modifier.height(8.dp))
            LimitProgress(used = row.used, limit = row.limit)
        }
    }
}
