package com.belanjabot.app.ui.expenses

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.belanjabot.app.data.Repository
import com.belanjabot.app.data.db.ExpenseEntity
import com.belanjabot.app.ui.components.EmptyState
import com.belanjabot.app.ui.components.ExpenseDetailDialog
import com.belanjabot.app.ui.components.ReceiptThumb
import com.belanjabot.app.util.Export
import com.belanjabot.app.util.ReceiptStore
import com.belanjabot.app.util.catEmoji
import com.belanjabot.app.util.catLabel
import com.belanjabot.app.util.formatRM
import com.belanjabot.app.util.prettyDate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

enum class ExpFilter(val label: String) { ALL("All"), MONTH("This month"), TAX("🧾 Tax-relief") }

class ExpensesViewModel : ViewModel() {
    private val db get() = Repository.db()
    val filter = MutableStateFlow(ExpFilter.ALL)

    val ui = combine(db.expenseDao().all(), filter) { list, f ->
        val ym = YearMonth.now()
        when (f) {
            ExpFilter.ALL -> list
            ExpFilter.MONTH -> list.filter {
                val d = LocalDate.ofEpochDay(it.dateEpochDay)
                d.year == ym.year && d.month == ym.month
            }
            ExpFilter.TAX -> list.filter { it.taxReliefCode != null }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList<ExpenseEntity>())

    fun delete(e: ExpenseEntity) = viewModelScope.launch {
        db.expenseDao().delete(e)
        ReceiptStore.delete(e.receiptPath)
    }
}

@Composable
fun ExpensesScreen(onViewReceipt: (String) -> Unit, vm: ExpensesViewModel = viewModel()) {
    val list by vm.ui.collectAsStateWithLifecycle()
    val filter by vm.filter.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<ExpenseEntity?>(null) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Expenses", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                scope.launch {
                    val f = Export.expensesCsv(ctx, list, filter.name.lowercase())
                    Export.share(ctx, listOf(f), "Share expenses CSV")
                }
            }) { Icon(Icons.Filled.Share, contentDescription = "Export") }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ExpFilter.entries.forEach { f ->
                FilterChip(
                    selected = filter == f,
                    onClick = { vm.filter.value = f },
                    label = { Text(f.label) }
                )
            }
        }
        Spacer(Modifier.height(8.dp))

        if (list.isEmpty()) {
            EmptyState("Nothing here yet. Tap + to record an expense.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val grouped = list.groupBy { it.dateEpochDay }.toSortedMap(compareByDescending { it })
                grouped.forEach { (day, itemsOfDay) ->
                    item(key = "hdr_$day") {
                        Text(prettyDate(day), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp))
                    }
                    items(itemsOfDay, key = { it.id }) { e ->
                        Card(onClick = { selected = e }) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (e.receiptPath != null) {
                                    ReceiptThumb(
                                        path = e.receiptPath,
                                        onOpen = onViewReceipt,
                                        heightDp = 48
                                    )
                                    Spacer(Modifier.padding(6.dp))
                                } else {
                                    Text(catEmoji(e.category), style = MaterialTheme.typography.titleLarge)
                                    Spacer(Modifier.padding(6.dp))
                                }
                                Column(Modifier.weight(1f)) {
                                    Text(e.note.ifBlank { catLabel(e.category) }, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                    Text(catLabel(e.category), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                if (e.taxReliefCode != null) Text("🧾 ")
                                Text(formatRM(e.amountCents), fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(90.dp)) }
            }
        }
    }

    selected?.let { e ->
        ExpenseDetailDialog(
            expense = e,
            onDelete = { vm.delete(e) },
            onOpenReceipt = onViewReceipt,
            onDismiss = { selected = null }
        )
    }
}
