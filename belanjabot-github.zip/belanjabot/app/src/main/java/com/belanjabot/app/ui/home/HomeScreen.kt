package com.belanjabot.app.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.belanjabot.app.data.Repository
import com.belanjabot.app.data.db.ExpenseEntity
import com.belanjabot.app.ui.components.CategoryBars
import com.belanjabot.app.ui.components.EmptyState
import com.belanjabot.app.ui.components.ExpenseDetailDialog
import com.belanjabot.app.ui.components.LimitProgress
import com.belanjabot.app.ui.components.StatCard
import com.belanjabot.app.util.BUDGET_ALL
import com.belanjabot.app.util.Export
import com.belanjabot.app.util.ReceiptStore
import com.belanjabot.app.util.catEmoji
import com.belanjabot.app.util.catLabel
import com.belanjabot.app.util.formatRM
import com.belanjabot.app.util.monthLabel
import com.belanjabot.app.util.prettyDate
import com.belanjabot.app.util.yearBounds
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

data class HomeUi(
    val month: YearMonth = YearMonth.now(),
    val monthTotal: Long = 0,
    val todayTotal: Long = 0,
    val overallLimit: Long = 0,
    val categoryTotals: List<Pair<String, Long>> = emptyList(),
    val recent: List<ExpenseEntity> = emptyList(),
    val monthExpenses: List<ExpenseEntity> = emptyList(),
    val savingsTotal: Long = 0,
    val taxClaimedYtd: Long = 0,
    val taxYear: Int = LocalDate.now().year
)

class HomeViewModel : ViewModel() {
    private val db get() = Repository.db()
    val month = MutableStateFlow(YearMonth.now())

    @OptIn(ExperimentalCoroutinesApi::class)
    private val monthExpenses = month.flatMapLatest { ym ->
        db.expenseDao().between(ym.atDay(1).toEpochDay(), ym.atEndOfMonth().toEpochDay())
    }

    private val budgets = db.budgetDao().all()
    private val savingsTotal = db.savingsDao().totalSaved()
    private val taxClaimed = run {
        val (from, to) = yearBounds(LocalDate.now().year)
        db.expenseDao().taxClaimedBetween(from, to)
    }

    val ui: StateFlow<HomeUi> = combine(month, monthExpenses, budgets, savingsTotal, taxClaimed) { m, exp, b, s, t ->
        val today = LocalDate.now().toEpochDay()
        HomeUi(
            month = m,
            monthTotal = exp.sumOf { it.amountCents },
            todayTotal = exp.filter { it.dateEpochDay == today }.sumOf { it.amountCents },
            overallLimit = b.firstOrNull { it.category == BUDGET_ALL }?.monthlyLimitCents ?: 0,
            categoryTotals = exp.groupBy { it.category }
                .mapValues { (_, v) -> v.sumOf { it.amountCents } }
                .toList().sortedByDescending { it.second },
            recent = exp.take(8),
            monthExpenses = exp,
            savingsTotal = s,
            taxClaimedYtd = t
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUi())

    fun setMonth(ym: YearMonth) { month.value = ym }

    fun deleteExpense(e: ExpenseEntity) = viewModelScope.launch {
        db.expenseDao().delete(e)
        ReceiptStore.delete(e.receiptPath)
    }
}

@Composable
fun HomeScreen(
    onSeeAll: () -> Unit,
    onOpenTax: () -> Unit,
    onViewReceipt: (String) -> Unit,
    vm: HomeViewModel = viewModel()
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var menuOpen by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<ExpenseEntity?>(null) }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.setMonth(ui.month.minusMonths(1)) }) {
                    Icon(Icons.Filled.KeyboardArrowLeft, contentDescription = "Previous month")
                }
                Text(
                    monthLabel(ui.month),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { vm.setMonth(ui.month.plusMonths(1)) }) {
                    Icon(Icons.Filled.KeyboardArrowRight, contentDescription = "Next month")
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Export this month (CSV)") },
                            onClick = {
                                menuOpen = false
                                scope.launch {
                                    val f = Export.expensesCsv(ctx, ui.monthExpenses, ui.month.toString())
                                    Export.share(ctx, listOf(f), "Share expenses CSV")
                                }
                            }
                        )
                    }
                }
            }
        }

        item {
            Card {
                Column(Modifier.padding(16.dp)) {
                    Text("Spent this month", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    Text(formatRM(ui.monthTotal), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    if (ui.overallLimit > 0) {
                        Spacer(Modifier.height(12.dp))
                        LimitProgress(used = ui.monthTotal, limit = ui.overallLimit)
                        val remaining = ui.overallLimit - ui.monthTotal
                        Text(
                            if (remaining >= 0) "✅ ${formatRM(remaining)} left to spend" else "⚠️ Over budget by ${formatRM(-remaining)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Spacer(Modifier.height(6.dp))
                        Text("Set a monthly budget in the Budget tab 🎯", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Today", formatRM(ui.todayTotal), Modifier.weight(1f))
                StatCard("Savings", formatRM(ui.savingsTotal), Modifier.weight(1f), subtitle = "all goals")
            }
            Spacer(Modifier.height(12.dp))
            StatCard(
                "🧾 Tax relief tagged (YA ${ui.taxYear})",
                formatRM(ui.taxClaimedYtd),
                Modifier.fillMaxWidth(),
                subtitle = "tap to review claimable categories",
                onClick = onOpenTax
            )
        }

        item {
            Text("By category", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (ui.categoryTotals.isEmpty()) EmptyState("No expenses this month yet. Tap + to add one.")
            else CategoryBars(ui.categoryTotals)
        }

        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Recent", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onSeeAll) { Text("See all") }
            }
        }
        items(ui.recent, key = { it.id }) { e ->
            Card(onClick = { selected = e }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(catEmoji(e.category), style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.padding(6.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.note.ifBlank { catLabel(e.category) }, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                        Text(prettyDate(e.dateEpochDay), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (e.receiptPath != null) Text("📷")
                    if (e.taxReliefCode != null) Text("🧾")
                    Spacer(Modifier.padding(4.dp))
                    Text(formatRM(e.amountCents), fontWeight = FontWeight.SemiBold)
                }
            }
        }
        item { Spacer(Modifier.height(90.dp)) }
    }

    selected?.let { e ->
        ExpenseDetailDialog(
            expense = e,
            onDelete = { vm.deleteExpense(e) },
            onOpenReceipt = onViewReceipt,
            onDismiss = { selected = null }
        )
    }
}
