package com.belanjabot.app.ui.savings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.belanjabot.app.data.Repository
import com.belanjabot.app.data.db.SavingsGoalEntity
import com.belanjabot.app.data.db.SavingsTxnEntity
import com.belanjabot.app.ui.components.EmptyState
import com.belanjabot.app.ui.components.InfoNote
import com.belanjabot.app.ui.components.LimitProgress
import com.belanjabot.app.util.formatRM
import com.belanjabot.app.util.parseToCents
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class GoalUi(val goal: SavingsGoalEntity, val saved: Long)

data class SavingsUi(val totalSaved: Long, val goals: List<GoalUi>)

class SavingsViewModel : ViewModel() {
    private val db get() = Repository.db()

    val ui = combine(db.savingsDao().goals(), db.savingsDao().txns()) { goals, txns ->
        SavingsUi(
            totalSaved = txns.sumOf { it.amountCents },
            goals = goals.map { g -> GoalUi(g, txns.filter { it.goalId == g.id }.sumOf { it.amountCents }) }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SavingsUi(0, emptyList()))

    fun addGoal(name: String, targetCents: Long) = viewModelScope.launch {
        db.savingsDao().upsertGoal(SavingsGoalEntity(name = name.trim(), targetCents = targetCents))
    }

    fun deleteGoal(id: Long) = viewModelScope.launch {
        db.savingsDao().deleteGoal(id)
        db.savingsDao().deleteTxnsOfGoal(id)
    }

    fun addFunds(goalId: Long, cents: Long, note: String) = viewModelScope.launch {
        db.savingsDao().addTxn(SavingsTxnEntity(goalId = goalId, amountCents = cents, note = note.trim()))
    }
}

@Composable
fun SavingsScreen(vm: SavingsViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var showNewGoal by remember { mutableStateOf(false) }
    var txnFor by remember { mutableStateOf<Pair<Long, Boolean>?>(null) } // goalId to isDeposit
    var confirmDelete by remember { mutableStateOf<GoalUi?>(null) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(10.dp))
        Text("Savings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Total saved", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(4.dp))
                        Text(formatRM(ui.totalSaved), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (ui.goals.isEmpty()) {
                item { EmptyState("No savings goals yet — create one and start putting money aside 💰") }
            }

            items(ui.goals, key = { it.goal.id }) { g ->
                val pct = if (g.goal.targetCents > 0) (g.saved * 100 / g.goal.targetCents).toInt() else 0
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(g.goal.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Text("${formatRM(g.saved)} of ${formatRM(g.goal.targetCents)} · $pct%",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            TextButton(onClick = { confirmDelete = g }) { Text("🗑️") }
                        }
                        Spacer(Modifier.height(8.dp))
                        LimitProgress(used = g.saved, limit = g.goal.targetCents)
                        if (g.saved >= g.goal.targetCents) {
                            Text("🎉 Goal reached!", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { txnFor = g.goal.id to true }, modifier = Modifier.weight(1f)) { Text("➕ Add funds") }
                            OutlinedButton(onClick = { txnFor = g.goal.id to false }, modifier = Modifier.weight(1f)) { Text("➖ Withdraw") }
                        }
                    }
                }
            }

            item {
                Button(onClick = { showNewGoal = true }, modifier = Modifier.fillMaxWidth()) { Text("➕ New savings goal") }
                Spacer(Modifier.height(8.dp))
                InfoNote("💡 Many Malaysians park savings in ASNB, SSPN (extra tax relief!) or Tabung Haji. Tag EPF top-ups as tax-relief expenses too.")
                Spacer(Modifier.height(90.dp))
            }
        }
    }

    if (showNewGoal) {
        var name by remember { mutableStateOf("") }
        var target by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewGoal = false },
            confirmButton = {
                TextButton(onClick = {
                    val cents = parseToCents(target)
                    if (name.isNotBlank() && cents != null && cents > 0) { vm.addGoal(name, cents); showNewGoal = false }
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showNewGoal = false }) { Text("Cancel") } },
            title = { Text("New savings goal") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Goal name (e.g. Emergency fund)") }, singleLine = true)
                    OutlinedTextField(value = target, onValueChange = { target = it }, label = { Text("Target amount") }, prefix = { Text("RM ") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                }
            }
        )
    }

    txnFor?.let { (goalId, isDeposit) ->
        var amount by remember { mutableStateOf("") }
        var noteText by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { txnFor = null },
            confirmButton = {
                TextButton(onClick = {
                    val cents = parseToCents(amount)
                    if (cents != null && cents > 0) {
                        vm.addFunds(goalId, if (isDeposit) cents else -cents, noteText)
                        txnFor = null
                    }
                }) { Text(if (isDeposit) "Add" else "Withdraw") }
            },
            dismissButton = { TextButton(onClick = { txnFor = null }) { Text("Cancel") } },
            title = { Text(if (isDeposit) "Add funds 💰" else "Withdraw 💸") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("Amount") }, prefix = { Text("RM ") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                    OutlinedTextField(value = noteText, onValueChange = { noteText = it }, label = { Text("Note (optional)") }, singleLine = true)
                }
            }
        )
    }

    confirmDelete?.let { g ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            confirmButton = {
                TextButton(onClick = { vm.deleteGoal(g.goal.id); confirmDelete = null }) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } },
            title = { Text("Delete \"${g.goal.name}\"?") },
            text = { Text("This also deletes its ${formatRM(g.saved)} savings records.") }
        )
    }
}
