package com.belanjabot.app.data

/**
 * Malaysian personal income tax relief categories (YA 2025 & YA 2026),
 * based on LHDN relief structure incl. Budget 2025 and Budget 2026 changes.
 */

data class ReliefDef(
    val code: String,
    val title: String,
    val what: String,
    /** RM limit by year of assessment. Missing year = relief not available that year. */
    val limits: Map<Int, Long>,
    val group: String? = null,
    val notes: String = ""
)

data class ReliefGroupDef(
    val code: String,
    val title: String,
    /** Combined RM cap by year. */
    val caps: Map<Int, Long>,
    val notes: String = ""
)

object TaxReliefs {

    val YEARS = listOf(2026, 2025)

    val groups = listOf(
        ReliefGroupDef(
            "G_MEDICAL", "Medical — self, spouse & child",
            mapOf(2025 to 10_000L, 2026 to 10_000L),
            "All items in this group share a combined cap of RM10,000."
        ),
        ReliefGroupDef(
            "G_LIFEEPF", "Life insurance & EPF",
            mapOf(2025 to 7_000L, 2026 to 7_000L),
            "Combined cap RM7,000 (EPF max RM4,000 + life insurance max RM3,000)."
        )
    )

    val reliefs = listOf(
        // --- Medical group (combined RM10,000) ---
        ReliefDef(
            "MED_SERIOUS", "Serious disease & fertility treatment",
            "Treatment of serious diseases for self, spouse or child; fertility treatment for self or spouse.",
            mapOf(2025 to 10_000L, 2026 to 10_000L), group = "G_MEDICAL",
            notes = "Keep official hospital / clinic receipts."
        ),
        ReliefDef(
            "MED_CHECKUP", "Check-up, vaccination, dental & mental health",
            "Complete medical check-up, NPRA-registered vaccination, disease-detection tests, self-test medical devices, dental exam & treatment, mental health consultation.",
            mapOf(2025 to 1_000L, 2026 to 1_000L), group = "G_MEDICAL",
            notes = "Sub-limit RM1,000 within the RM10,000 medical cap. YA2026: vaccines expanded to all NPRA-registered ones."
        ),
        ReliefDef(
            "CHILD_DISABILITY", "Child learning-disability care",
            "Diagnosis assessment, early intervention programme and rehabilitation for children aged 18 and below.",
            mapOf(2025 to 6_000L, 2026 to 10_000L), group = "G_MEDICAL",
            notes = "Sub-limit within the RM10,000 medical cap: RM6,000 (YA2025), raised to RM10,000 (YA2026)."
        ),

        // --- Life insurance & EPF group (combined RM7,000) ---
        ReliefDef(
            "EPF", "EPF contributions",
            "Mandatory and voluntary EPF (KWSP) contributions — employee share.",
            mapOf(2025 to 4_000L, 2026 to 4_000L), group = "G_LIFEEPF"
        ),
        ReliefDef(
            "LIFE_INS", "Life insurance / family takaful",
            "Life insurance premiums or family takaful contributions on your own life.",
            mapOf(2025 to 3_000L, 2026 to 3_000L), group = "G_LIFEEPF"
        ),

        // --- Standalone reliefs ---
        ReliefDef(
            "PARENTS_MED", "Parents' medical, care & special needs",
            "Medical treatment, dental, special needs and carer expenses for parents (condition certified by a medical practitioner).",
            mapOf(2025 to 8_000L, 2026 to 8_000L),
            notes = "From YA2025 the scope is extended to grandparents. Complete medical exam sub-limit RM1,000."
        ),
        ReliefDef(
            "DISABLED_EQUIP", "Basic supporting equipment (disabled)",
            "Purchase of basic supporting equipment for disabled self, spouse, child or parent.",
            mapOf(2025 to 6_000L, 2026 to 6_000L)
        ),
        ReliefDef(
            "EDU_SELF", "Education fees (self)",
            "Approved tertiary courses and recognised qualifications; upskilling / self-enhancement courses limited to RM2,000 within this amount.",
            mapOf(2025 to 7_000L, 2026 to 7_000L),
            notes = "Upskilling sub-limit (RM2,000) extended to YA2026."
        ),
        ReliefDef(
            "LIFESTYLE", "Lifestyle (books, gadgets, internet, courses)",
            "Books, journals, magazines, newspapers; personal computer, smartphone or tablet (non-business); internet subscription; skill-improvement / personal development course fees.",
            mapOf(2025 to 2_500L, 2026 to 2_500L)
        ),
        ReliefDef(
            "SPORTS", "Sports equipment & activities",
            "Sports equipment, sports-facility rental or entrance fees, approved competition registration fees, gym membership and sports training.",
            mapOf(2025 to 1_000L, 2026 to 1_000L)
        ),
        ReliefDef(
            "BREASTFEED", "Breastfeeding equipment",
            "Purchase of breastfeeding equipment for own use (child aged 2 years and below).",
            mapOf(2025 to 1_000L, 2026 to 1_000L),
            notes = "Claimable once every 2 years of assessment."
        ),
        ReliefDef(
            "CHILDCARE", "Childcare & kindergarten fees",
            "Fees to a registered childcare centre (TASKA) or kindergarten (TADIKA).",
            mapOf(2025 to 3_000L, 2026 to 3_000L),
            notes = "YA2026: scope extended to registered care centres for children up to 12 years old."
        ),
        ReliefDef(
            "SSPN", "SSPN net deposits",
            "Net deposit (deposits minus withdrawals) into Skim Simpanan Pendidikan Nasional for your child.",
            mapOf(2025 to 8_000L, 2026 to 8_000L),
            notes = "Extended to YA2027. Claimable by either parent."
        ),
        ReliefDef(
            "PRS", "Private Retirement Scheme & annuity",
            "Contributions to an approved Private Retirement Scheme or deferred annuity premiums.",
            mapOf(2025 to 3_000L, 2026 to 3_000L)
        ),
        ReliefDef(
            "EDUMED_INS", "Education & medical insurance",
            "Education and medical insurance premiums for self, spouse or child.",
            mapOf(2025 to 4_000L, 2026 to 4_000L),
            notes = "Increased from RM3,000 to RM4,000 from YA2025."
        ),
        ReliefDef(
            "SOCSO", "SOCSO / EIS contributions",
            "Social Security Organisation (PERKESO) and Employment Insurance System contributions.",
            mapOf(2025 to 350L, 2026 to 350L)
        ),
        ReliefDef(
            "EV_CHARGE", "EV charging & home green-tech",
            "Installation, rental, purchase (incl. hire-purchase) or subscription of EV home-charging facilities; household food-waste composting machine.",
            mapOf(2025 to 2_500L, 2026 to 2_500L),
            notes = "YA2026–2027: scope extended to home food-waste grinders and CCTV (one purchase each, once per 2 YAs)."
        ),
        ReliefDef(
            "HOME_LOAN_INT", "First-home loan interest",
            "Housing loan interest for a first residential home — SPA signed between 1 Jan 2025 and 31 Dec 2027, for the first 3 consecutive YAs.",
            mapOf(2025 to 7_000L, 2026 to 7_000L),
            notes = "Up to RM7,000/yr for homes ≤ RM500,000; up to RM5,000/yr for homes RM500,000–RM750,000. Home must not generate income."
        ),
        ReliefDef(
            "TOURISM", "Tourist attractions & cultural programmes",
            "Entrance fees to local tourist attractions and arts / cultural programmes.",
            mapOf(2026 to 1_000L),
            notes = "New relief for YA2026 only."
        )
    )

    /** Automatic (no receipt tracking needed) — shown as reference only. */
    val automatic = listOf(
        "Individual & dependent relatives — RM9,000 (granted automatically)",
        "Spouse / alimony to former wife — up to RM4,000",
        "Disabled individual — RM7,000 (raised from RM6,000 in YA2025)",
        "Disabled spouse — RM6,000 (raised from RM5,000 in YA2025)",
        "Child under 18 — RM2,000 each",
        "Child 18+ in full-time education — RM2,000 (pre-university) or up to RM8,000 (tertiary)",
        "Disabled child — RM8,000 (raised from RM6,000 in YA2025); +RM8,000 more if in higher education",
        "Zakat / fitrah / Islamic religious dues — tax rebate of the actual amount paid",
        "Departure levy for umrah / pilgrimage — rebate (max 2 trips in a lifetime)"
    )

    fun forYear(year: Int) = reliefs.filter { it.limits.containsKey(year) }
    fun byCode(code: String?) = reliefs.firstOrNull { it.code == code }
    fun groupOf(code: String?) = groups.firstOrNull { it.code == code }
}
