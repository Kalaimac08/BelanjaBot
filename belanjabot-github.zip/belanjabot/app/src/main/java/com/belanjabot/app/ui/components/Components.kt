package com.belanjabot.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.belanjabot.app.data.TaxReliefs
import com.belanjabot.app.data.db.ExpenseEntity
import com.belanjabot.app.ui.theme.Warning
import com.belanjabot.app.util.catEmoji
import com.belanjabot.app.util.catLabel
import com.belanjabot.app.util.formatRM
import com.belanjabot.app.util.prettyDate
import java.io.File

@Composable
fun StatCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = modifier.then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (subtitle != null) {
                Spacer(Modifier.height(2.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun LimitProgress(used: Long, limit: Long, modifier: Modifier = Modifier) {
    val ratio = if (limit <= 0) 0f else (used.toFloat() / limit).coerceIn(0f, 1f)
    val color = when {
        ratio >= 1f -> MaterialTheme.colorScheme.error
        ratio >= 0.8f -> Warning
        else -> MaterialTheme.colorScheme.primary
    }
    Column(modifier) {
        LinearProgressIndicator(
            progress = { ratio },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = color,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Used ${formatRM(used)}", style = MaterialTheme.typography.bodySmall)
            Text("Limit ${formatRM(limit)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun CategoryBars(totals: List<Pair<String, Long>>, modifier: Modifier = Modifier) {
    val max = totals.maxOfOrNull { it.second }?.takeIf { it > 0 } ?: return
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        totals.take(8).forEach { (cat, amount) ->
            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${catEmoji(cat)}  ${catLabel(cat)}", style = MaterialTheme.typography.bodyMedium)
                    Text(formatRM(amount), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { (amount.toFloat() / max).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }
    }
}

@Composable
fun EmptyState(text: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🧾", style = MaterialTheme.typography.displaySmall)
        Spacer(Modifier.height(8.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun InfoNote(text: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(12.dp)) {
        Text(
            text,
            modifier = Modifier.padding(12.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/** Small tappable receipt preview. */
@Composable
fun ReceiptThumb(path: String, onOpen: (String) -> Unit, modifier: Modifier = Modifier, heightDp: Int = 180) {
    Box(
        modifier
            .height(heightDp.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onOpen(path) }
    ) {
        AsyncImage(
            model = File(path),
            contentDescription = "Receipt photo",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Icon(
            Icons.Filled.ZoomIn,
            contentDescription = "Zoom",
            tint = Color.White,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
                .background(Color(0x66000000), CircleShape)
                .padding(6.dp)
        )
    }
}

/** Full-screen in-app receipt viewer with pinch-to-zoom & pan. */
@Composable
fun ReceiptViewerDialog(path: String, onDismiss: () -> Unit) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        var scale by remember { mutableFloatStateOf(1f) }
        var offset by remember { mutableStateOf(Offset.Zero) }
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 6f)
                        offset = if (scale <= 1f) Offset.Zero else offset + pan
                    }
                }
        ) {
            AsyncImage(
                model = File(path),
                contentDescription = "Receipt",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offset.x
                        translationY = offset.y
                    }
            )
            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(14.dp)
                    .background(Color(0x66000000), CircleShape)
            ) { Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.White) }
            Text(
                "Pinch to zoom · drag to pan",
                color = Color.White.copy(alpha = 0.75f),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(18.dp)
            )
        }
    }
}

/** Detail dialog for one expense, with embedded receipt preview. */
@Composable
fun ExpenseDetailDialog(
    expense: ExpenseEntity,
    onDelete: () -> Unit,
    onOpenReceipt: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        dismissButton = {
            TextButton(onClick = { onDelete(); onDismiss() }) {
                Text("Delete", color = MaterialTheme.colorScheme.error)
            }
        },
        title = { Text(expense.note.ifBlank { catLabel(expense.category) }) },
        text = {
            Column {
                Text(
                    "${formatRM(expense.amountCents)}\n${prettyDate(expense.dateEpochDay)} · ${catLabel(expense.category)}" +
                        (TaxReliefs.byCode(expense.taxReliefCode)?.let { "\n🧾 ${it.title}" } ?: "")
                )
                expense.receiptPath?.let { path ->
                    if (File(path).exists()) {
                        Spacer(Modifier.height(10.dp))
                        ReceiptThumb(path, onOpenReceipt, Modifier.fillMaxWidth(), heightDp = 200)
                        Spacer(Modifier.height(4.dp))
                        Text("Tap the receipt to zoom 🔎", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Spacer(Modifier.height(6.dp))
                        Text("⚠️ Receipt file missing (was it deleted?)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    )
}

/** List of expenses (used on the Tax tab) with receipt thumbnails. */
@Composable
fun ExpenseListDialog(
    title: String,
    expenses: List<ExpenseEntity>,
    onOpenReceipt: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text(title) },
        text = {
            if (expenses.isEmpty()) {
                Text("No tagged expenses yet.")
            } else {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(expenses, key = { it.id }) { e ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable(enabled = e.receiptPath != null) {
                                    e.receiptPath?.let(onOpenReceipt)
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (e.receiptPath != null && File(e.receiptPath).exists()) {
                                AsyncImage(
                                    model = File(e.receiptPath),
                                    contentDescription = "Receipt",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                )
                                Spacer(Modifier.padding(5.dp))
                            }
                            Column(Modifier.weight(1f)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(
                                        e.note.ifBlank { catLabel(e.category) },
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(formatRM(e.amountCents), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                }
                                Text(
                                    "${prettyDate(e.dateEpochDay)} · ${catLabel(e.category)}" +
                                        if (e.receiptPath != null) " · 📷 tap to view" else "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    )
}
