package com.belanjabot.app.ui.expenses

import android.app.Application
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import coil.compose.AsyncImage
import com.belanjabot.app.data.Repository
import com.belanjabot.app.data.TaxReliefs
import com.belanjabot.app.data.db.ExpenseEntity
import com.belanjabot.app.util.EXPENSE_CATEGORIES
import com.belanjabot.app.util.ReceiptStore
import com.belanjabot.app.util.epochDayToMillis
import com.belanjabot.app.util.millisToEpochDay
import com.belanjabot.app.util.parseToCents
import com.belanjabot.app.util.prettyDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate

class AddExpenseViewModel(app: Application) : AndroidViewModel(app) {

    companion object { private const val TAG = "BelanjaReceipt" }

    private val db get() = Repository.db()

    val amountText = MutableStateFlow("")
    val category = MutableStateFlow("FOOD")
    val note = MutableStateFlow("")
    val dateEpochDay = MutableStateFlow(LocalDate.now().toEpochDay())
    val taxEnabled = MutableStateFlow(false)
    val reliefCode = MutableStateFlow<String?>(null)
    val receiptPath = MutableStateFlow<String?>(null)
    val saving = MutableStateFlow(false)

    fun setReceiptFromUri(uri: Uri) = viewModelScope.launch {
        Log.d(TAG, "gallery picked: $uri")
        val p = withContext(Dispatchers.IO) { ReceiptStore.import(getApplication(), uri) }
        if (p == null || !File(p).exists()) {
            Log.e(TAG, "gallery import FAILED for $uri")
            Toast.makeText(getApplication(), "Couldn't load that image 😢 Try taking a photo instead.", Toast.LENGTH_SHORT).show()
        } else {
            receiptPath.value = p
            Log.d(TAG, "gallery import OK -> $p (UI state updated)")
            Toast.makeText(getApplication(), "Receipt attached ✅", Toast.LENGTH_SHORT).show()
        }
    }

    fun setReceiptFromFile(f: File) = viewModelScope.launch {
        Log.d(TAG, "camera capture: ${f.absolutePath}")
        val p = withContext(Dispatchers.IO) { ReceiptStore.importFile(getApplication(), f) }
        if (p == null || !File(p).exists()) {
            Log.e(TAG, "camera import FAILED for ${f.absolutePath}")
            Toast.makeText(getApplication(), "Couldn't save the photo 😢", Toast.LENGTH_SHORT).show()
        } else {
            receiptPath.value = p
            Log.d(TAG, "camera import OK -> $p (UI state updated)")
        }
    }

    fun clearReceipt() {
        ReceiptStore.delete(receiptPath.value)
        receiptPath.value = null
    }

    fun save(onSaved: () -> Unit) {
        if (saving.value) return
        val cents = parseToCents(amountText.value)
        if (cents == null || cents <= 0) {
            Toast.makeText(getApplication(), "Please enter a valid amount", Toast.LENGTH_SHORT).show()
            return
        }
        saving.value = true
        viewModelScope.launch {
            db.expenseDao().upsert(
                ExpenseEntity(
                    amountCents = cents,
                    category = category.value,
                    note = note.value.trim(),
                    dateEpochDay = dateEpochDay.value,
                    taxReliefCode = if (taxEnabled.value) reliefCode.value else null,
                    receiptPath = receiptPath.value
                )
            )
            Log.d(TAG, "expense saved, receiptPath=${receiptPath.value}")
            saving.value = false
            onSaved()
        }
    }

    fun reset() {
        amountText.value = ""
        category.value = "FOOD"
        note.value = ""
        dateEpochDay.value = LocalDate.now().toEpochDay()
        taxEnabled.value = false
        reliefCode.value = null
        receiptPath.value = null
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddExpenseScreen(onDone: () -> Unit) {
    val vm: AddExpenseViewModel = viewModel(factory = viewModelFactory {
        initializer {
            val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY]!!
            AddExpenseViewModel(app)
        }
    })

    val amount by vm.amountText.collectAsStateWithLifecycle()
    val category by vm.category.collectAsStateWithLifecycle()
    val note by vm.note.collectAsStateWithLifecycle()
    val dateEpochDay by vm.dateEpochDay.collectAsStateWithLifecycle()
    val taxEnabled by vm.taxEnabled.collectAsStateWithLifecycle()
    val reliefCode by vm.reliefCode.collectAsStateWithLifecycle()
    val receiptPath by vm.receiptPath.collectAsStateWithLifecycle()
    val saving by vm.saving.collectAsStateWithLifecycle()

    val ctx = LocalContext.current
    var showDatePicker by remember { mutableStateOf(false) }
    var reliefMenuOpen by remember { mutableStateOf(false) }

    // --- receipt capture launchers ---
    val tmpCameraFile = remember { mutableStateOf<File?>(null) }
    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) tmpCameraFile.value?.let { vm.setReceiptFromFile(it) }
    }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { vm.setReceiptFromUri(it) }
    }

    val dateYear = LocalDate.ofEpochDay(dateEpochDay).year
    val reliefsThisYear = remember(dateYear) { TaxReliefs.forYear(dateYear) }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Add expense") },
            navigationIcon = {
                IconButton(onClick = onDone) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            }
        )
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Amount
            OutlinedTextField(
                value = amount,
                onValueChange = { vm.amountText.value = it },
                label = { Text("Amount") },
                prefix = { Text("RM ") },
                placeholder = { Text("0.00") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                textStyle = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.fillMaxWidth()
            )

            // Category
            Column {
                Text("Category", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    EXPENSE_CATEGORIES.forEach { c ->
                        FilterChip(
                            selected = category == c.key,
                            onClick = { vm.category.value = c.key },
                            label = { Text("${c.emoji} ${c.label}") }
                        )
                    }
                }
            }

            // Date
            OutlinedButton(onClick = { showDatePicker = true }, modifier = Modifier.fillMaxWidth()) {
                Text("📅  ${prettyDate(dateEpochDay)}")
            }

            // Note
            OutlinedTextField(
                value = note,
                onValueChange = { vm.note.value = it },
                label = { Text("Note (e.g. Nasi lemak breakfast)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Tax relief
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("🧾 Tax deductible?", style = MaterialTheme.typography.bodyLarge)
                        Text("Tag it to a LHDN tax relief category", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = taxEnabled, onCheckedChange = {
                        vm.taxEnabled.value = it
                        if (it && reliefCode == null) vm.reliefCode.value = reliefsThisYear.firstOrNull()?.code
                    })
                }
                if (taxEnabled) {
                    Spacer(Modifier.height(8.dp))
                    Box {
                        OutlinedTextField(
                            value = TaxReliefs.byCode(reliefCode)?.title ?: "Select category",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Tax relief (YA $dateYear)") },
                            trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Box(Modifier.matchParentSize().clickable { reliefMenuOpen = true })
                        DropdownMenu(expanded = reliefMenuOpen, onDismissRequest = { reliefMenuOpen = false }) {
                            reliefsThisYear.forEach { r ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(r.title)
                                            Text("Limit RM ${r.limits[dateYear]}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    },
                                    onClick = { vm.reliefCode.value = r.code; reliefMenuOpen = false }
                                )
                            }
                        }
                    }
                }
            }

            // Receipt
            Column {
                Text("Receipt", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        val f = ReceiptStore.newTempCameraFile(ctx)
                        tmpCameraFile.value = f
                        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                        camLauncher.launch(uri)
                    }) { Text("📷 Take photo") }
                    OutlinedButton(onClick = { galleryLauncher.launch("image/*") }) { Text("🖼️ From gallery") }
                }
                if (receiptPath != null) {
                    Spacer(Modifier.height(8.dp))
                    Box {
                        AsyncImage(
                            model = File(receiptPath!!),
                            contentDescription = "Receipt",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                        IconButton(
                            onClick = { vm.clearReceipt() },
                            modifier = Modifier.align(Alignment.TopEnd)
                        ) { Icon(Icons.Filled.Close, contentDescription = "Remove receipt") }
                    }
                }
            }

            Button(
                onClick = { vm.save(onDone) },
                enabled = !saving,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save expense") }
            OutlinedButton(
                onClick = {
                    vm.save {
                        vm.reset()
                        Toast.makeText(ctx, "Saved! Add another 👇", Toast.LENGTH_SHORT).show()
                    }
                },
                enabled = !saving,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save & add another") }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showDatePicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = epochDayToMillis(dateEpochDay))
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { vm.dateEpochDay.value = millisToEpochDay(it) }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("Cancel") } }
        ) { DatePicker(state = state) }
    }
}
