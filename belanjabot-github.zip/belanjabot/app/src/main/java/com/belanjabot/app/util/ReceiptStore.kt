package com.belanjabot.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Log
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream

object ReceiptStore {

    private const val TAG = "BelanjaReceipt"

    fun dir(context: Context): File = File(context.filesDir, "receipts").apply { mkdirs() }

    fun newTempCameraFile(context: Context): File =
        File(File(context.cacheDir, "camera").apply { mkdirs() }, "cam_${System.currentTimeMillis()}.jpg")

    /**
     * Import an image from a content Uri (gallery picker) into private storage.
     * Copies the picked stream ONCE to a temp file (many providers — Samsung Gallery,
     * Google Photos — do not allow reopening a content Uri), then reuses the
     * file-based camera path. Returns the stored absolute path, or null on failure.
     */
    fun import(context: Context, uri: Uri): String? {
        Log.d(TAG, "import() start: $uri")
        val tmp = File(context.cacheDir, "pick_${System.currentTimeMillis()}.tmp")
        val copied = runCatching {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tmp).use { output -> input.copyTo(output, 64 * 1024) }
            } ?: run {
                Log.e(TAG, "import(): openInputStream returned null")
                return null
            }
            tmp.length() > 0
        }.onFailure {
            Log.e(TAG, "import(): failed to copy picked image", it)
        }.getOrDefault(false)

        if (!copied) {
            Log.e(TAG, "import(): copy produced empty file")
            tmp.delete()
            return null
        }
        Log.d(TAG, "import(): copied ${tmp.length()} bytes, decoding…")
        val result = importFile(context, tmp)
        tmp.delete()
        Log.d(TAG, "import() done -> $result")
        return result
    }

    /** Import a captured camera file into private storage, rotated & downscaled. */
    fun importFile(context: Context, src: File): String? {
        val out = File(dir(context), "rcp_${System.currentTimeMillis()}.jpg")
        val ok = runCatching {
            var bmp = decodeScaled(src) ?: throw IllegalStateException("decode failed (unsupported image?)")
            bmp = rotate(bmp, exifRotation(src.absolutePath))
            FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        }.onFailure {
            Log.e(TAG, "importFile() failed for ${src.absolutePath}", it)
        }.isSuccess
        if (ok) Log.d(TAG, "importFile() saved: ${out.absolutePath} (${out.length()} bytes)")
        return if (ok) out.absolutePath else null
    }

    fun delete(path: String?) {
        if (!path.isNullOrBlank()) runCatching { File(path).delete() }
    }

    private fun targetSample(w: Int, h: Int): Int {
        var sample = 1
        while (w / (sample * 2) >= 1400 && h / (sample * 2) >= 1400) sample *= 2
        return sample
    }

    private fun rotate(bmp: Bitmap, deg: Int): Bitmap {
        if (deg == 0) return bmp
        val m = Matrix().apply { postRotate(deg.toFloat()) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true).also { if (it !== bmp) bmp.recycle() }
    }

    private fun exifRotation(filePath: String): Int = runCatching {
        ExifInterface(filePath).rotationDegrees
    }.getOrDefault(0)

    private fun decodeScaled(f: File): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, opts)
        if (opts.outWidth <= 0) return null
        val o2 = BitmapFactory.Options().apply { inSampleSize = targetSample(opts.outWidth, opts.outHeight) }
        return BitmapFactory.decodeFile(f.absolutePath, o2)
    }
}
