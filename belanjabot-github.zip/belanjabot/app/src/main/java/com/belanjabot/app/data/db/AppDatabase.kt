package com.belanjabot.app.data.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "expenses", indices = [Index("dateEpochDay")])
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amountCents: Long,
    val category: String,
    val note: String,
    val dateEpochDay: Long,
    val taxReliefCode: String? = null,
    val receiptPath: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "budgets")
data class BudgetEntity(
    @PrimaryKey val category: String, // "ALL" = overall monthly budget
    val monthlyLimitCents: Long
)

@Entity(tableName = "savings_goals")
data class SavingsGoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val targetCents: Long,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "savings_txns", indices = [Index("goalId")])
data class SavingsTxnEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val goalId: Long,
    val amountCents: Long, // negative = withdrawal
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface ExpenseDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(e: ExpenseEntity): Long

    @Delete
    suspend fun delete(e: ExpenseEntity)

    @Query("SELECT * FROM expenses ORDER BY dateEpochDay DESC, createdAt DESC LIMIT 1000")
    fun all(): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE dateEpochDay BETWEEN :from AND :to ORDER BY dateEpochDay DESC, createdAt DESC")
    fun between(from: Long, to: Long): Flow<List<ExpenseEntity>>

    @Query("SELECT COALESCE(SUM(amountCents),0) FROM expenses WHERE taxReliefCode IS NOT NULL AND dateEpochDay BETWEEN :from AND :to")
    fun taxClaimedBetween(from: Long, to: Long): Flow<Long>
}

@Dao
interface BudgetDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(b: BudgetEntity)

    @Query("DELETE FROM budgets WHERE category = :category")
    suspend fun delete(category: String)

    @Query("SELECT * FROM budgets")
    fun all(): Flow<List<BudgetEntity>>
}

@Dao
interface SavingsDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertGoal(g: SavingsGoalEntity): Long

    @Query("DELETE FROM savings_goals WHERE id = :id")
    suspend fun deleteGoal(id: Long)

    @Query("DELETE FROM savings_txns WHERE goalId = :goalId")
    suspend fun deleteTxnsOfGoal(goalId: Long)

    @Insert
    suspend fun addTxn(t: SavingsTxnEntity): Long

    @Query("SELECT * FROM savings_goals ORDER BY createdAt DESC")
    fun goals(): Flow<List<SavingsGoalEntity>>

    @Query("SELECT * FROM savings_txns ORDER BY createdAt DESC")
    fun txns(): Flow<List<SavingsTxnEntity>>

    @Query("SELECT COALESCE(SUM(amountCents),0) FROM savings_txns")
    fun totalSaved(): Flow<Long>
}

@Database(
    entities = [ExpenseEntity::class, BudgetEntity::class, SavingsGoalEntity::class, SavingsTxnEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun expenseDao(): ExpenseDao
    abstract fun budgetDao(): BudgetDao
    abstract fun savingsDao(): SavingsDao
}
