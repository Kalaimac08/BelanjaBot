package com.belanjabot.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.belanjabot.app.ui.budget.BudgetScreen
import com.belanjabot.app.ui.components.ReceiptViewerDialog
import com.belanjabot.app.ui.expenses.AddExpenseScreen
import com.belanjabot.app.ui.expenses.ExpensesScreen
import com.belanjabot.app.ui.home.HomeScreen
import com.belanjabot.app.ui.savings.SavingsScreen
import com.belanjabot.app.ui.tax.TaxScreen

data class TabItem(val route: String, val label: String, val icon: ImageVector)

@Composable
fun AppRoot() {
    val nav = rememberNavController()
    var receiptToView by remember { mutableStateOf<String?>(null) }

    val tabs = listOf(
        TabItem("home", "Home", Icons.Filled.Home),
        TabItem("expenses", "Expenses", Icons.Filled.ReceiptLong),
        TabItem("budget", "Budget", Icons.Filled.AccountBalanceWallet),
        TabItem("savings", "Savings", Icons.Filled.Savings),
        TabItem("tax", "Tax", Icons.Filled.Assessment)
    )
    val backStackEntry by nav.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route

    Box {
        Scaffold(
            floatingActionButton = {
                if (route == "home" || route == "expenses") {
                    FloatingActionButton(onClick = { nav.navigate("add") }) {
                        Icon(Icons.Filled.Add, contentDescription = "Add expense")
                    }
                }
            },
            bottomBar = {
                if (route != "add") {
                    NavigationBar {
                        tabs.forEach { t ->
                            NavigationBarItem(
                                selected = route == t.route,
                                onClick = {
                                    nav.navigate(t.route) {
                                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(t.icon, contentDescription = t.label) },
                                label = { Text(t.label, maxLines = 1, softWrap = false) }
                            )
                        }
                    }
                }
            }
        ) { padding ->
            NavHost(navController = nav, startDestination = "home", modifier = Modifier.padding(padding)) {
                composable("home") {
                    HomeScreen(
                        onSeeAll = { nav.navigate("expenses") },
                        onOpenTax = { nav.navigate("tax") },
                        onViewReceipt = { receiptToView = it }
                    )
                }
                composable("expenses") { ExpensesScreen(onViewReceipt = { receiptToView = it }) }
                composable("add") { AddExpenseScreen(onDone = { nav.popBackStack() }) }
                composable("budget") { BudgetScreen() }
                composable("savings") { SavingsScreen() }
                composable("tax") { TaxScreen(onViewReceipt = { receiptToView = it }) }
            }
        }

        // Full-screen in-app receipt viewer (zoomable)
        receiptToView?.let { path ->
            ReceiptViewerDialog(path = path, onDismiss = { receiptToView = null })
        }
    }
}
