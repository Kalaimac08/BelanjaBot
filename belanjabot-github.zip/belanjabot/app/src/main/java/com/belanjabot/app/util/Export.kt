package com.belanjabot.app.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.belanjabot.app.data.TaxReliefs
import com.belanjabot.app.data.db.ExpenseEntity
import java.io.File
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

object Export {

    private fun esc(s: String): String =
        if (s.any { it == ',' || it == '"' || it == '\n' }) "\"${s.replace("\"", "\"\"")}\"" else s

    private fun rm(cents: Long) = String.format(Locale.US, "%.2f", cents / 100.0)

    private fun write(context: Context, name: String, content: String): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        return File(dir, name).apply { writeText(content) }
    }

    fun expensesCsv(context: Context, items: List<ExpenseEntity>, label: String): File {
        val sb = StringBuilder("Date,Amount (RM),Category,Note,Tax Relief,Receipt File\n")
        for (e in items) {
            sb.appendLine(
                listOf(
                    LocalDate.ofEpochDay(e.dateEpochDay).toString(),
                    rm(e.amountCents),
                    esc(catLabel(e.category)),
                    esc(e.note),
                    esc(TaxReliefs.byCode(e.taxReliefCode)?.title ?: ""),
                    File(e.receiptPath ?: "").name
                ).joinToString(",")
            )
        }
        return write(context, "expenses_$label.csv", sb.toString())
    }

    /** Tax relief CSV: one row per relief category + detail of tagged expenses. */
    fun taxCsv(context: Context, year: Int, items: List<ExpenseEntity>): File {
        val used = items.filter { it.taxReliefCode != null }
            .groupBy { it.taxReliefCode!! }
            .mapValues { (_, v) -> v.sumOf { it.amountCents } }

        val sb = StringBuilder("BelanjaBot — Tax Relief Summary for YA $year\n")
        sb.append("Relief Category,Limit (RM),Claimed (RM),Effective (RM)\n")
        var totalEffective = 0L
        for (r in TaxReliefs.forYear(year)) {
            val claimed = used[r.code] ?: 0L
            val limit = r.limits[year] ?: continue
            val effective = minOf(claimed, limit)
            totalEffective += effective
            sb.appendLine("${esc(r.title)},${r.limits[year]},${rm(claimed)},${rm(effective)}")
        }
        // Group caps (medical RM10k, life+EPF RM7k)
        var groupAdjust = 0L
        for (g in TaxReliefs.groups) {
            val cap = g.caps[year] ?: continue
            val members = TaxReliefs.forYear(year).filter { it.group == g.code }
            val memberEff = members.sumOf { minOf(used[it.code] ?: 0L, it.limits[year]!!) }
            if (memberEff > cap) {
                groupAdjust += memberEff - cap
                sb.appendLine("${esc(g.title)} — combined cap exceeded,${cap},${rm(memberEff)},-${rm(memberEff - cap)}")
            }
        }
        val total = totalEffective - groupAdjust
        sb.appendLine()
        sb.appendLine("TOTAL EFFECTIVE RELIEF (after caps),,,${rm(total)}")
        sb.appendLine()
        sb.appendLine("Tagged expense entries")
        sb.appendLine("Date,Description,Amount (RM),Relief Category,Receipt File")
        for (e in items.filter { it.taxReliefCode != null }) {
            sb.appendLine(
                listOf(
                    LocalDate.ofEpochDay(e.dateEpochDay).toString(),
                    esc(e.note),
                    rm(e.amountCents),
                    esc(TaxReliefs.byCode(e.taxReliefCode)?.title ?: e.taxReliefCode!!),
                    File(e.receiptPath ?: "").name
                ).joinToString(",")
            )
        }
        return write(context, "tax_relief_YA$year.csv", sb.toString())
    }

    fun share(context: Context, files: List<File>, chooserTitle: String) {
        val uris = ArrayList(
            files.filter { it.exists() }.map {
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", it)
            }
        )
        if (uris.isEmpty()) return
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "text/csv"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, chooserTitle))
    }

    fun openReceipt(context: Context, path: String) {
        runCatching {
            val f = File(path)
            if (!f.exists()) return
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "image/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            context.startActivity(i)
        }
    }

    fun defaultExpenseLabel(): String = YearMonth.now().toString()
}
