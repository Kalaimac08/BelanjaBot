package com.belanjabot.app.ui.budget

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.belanjabot.app.data.Repository
import com.belanjabot.app.data.db.BudgetEntity
import com.belanjabot.app.ui.components.EmptyState
import com.belanjabot.app.ui.components.InfoNote
import com.belanjabot.app.ui.components.LimitProgress
import com.belanjabot.app.util.BUDGET_ALL
import com.belanjabot.app.util.EXPENSE_CATEGORIES
import com.belanjabot.app.util.catEmoji
import com.belanjabot.app.util.catLabel
import com.belanjabot.app.util.formatRM
import com.belanjabot.app.util.monthLabel
import com.belanjabot.app.util.parseToCents
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.YearMonth

data class BudgetRow(val category: String, val limit: Long, val spent: Long)

data class BudgetUi(val monthLabel: String, val overall: BudgetRow?, val rows: List<BudgetRow>)

class BudgetViewModel : ViewModel() {
    private val db get() = Repository.db()

    private val now = YearMonth.now()
    private val monthExp = db.expenseDao().between(now.atDay(1).toEpochDay(), now.atEndOfMonth().toEpochDay())
    private val budgets = db.budgetDao().all()

    val ui = combine(monthExp, budgets) { exp, bs ->
        val spentByCat = exp.groupBy { it.category }.mapValues { (_, v) -> v.sumOf { it.amountCents } }
        val total = exp.sumOf { it.amountCents }
        BudgetUi(
            monthLabel = monthLabel(now),
            overall = bs.firstOrNull { it.category == BUDGET_ALL }
                ?.let { BudgetRow(BUDGET_ALL, it.monthlyLimitCents, total) },
            rows = bs.filter { it.category != BUDGET_ALL }
                .map { BudgetRow(it.category, it.monthlyLimitCents, spentByCat[it.category] ?: 0) }
                .sortedByDescending { it.spent }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BudgetUi(monthLabel(now), null, emptyList()))

    fun setBudget(category: String, cents: Long) = viewModelScope.launch {
        if (cents <= 0) db.budgetDao().delete(category)
        else db.budgetDao().upsert(BudgetEntity(category, cents))
    }
}

@Composable
fun BudgetScreen(vm: BudgetViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<String?>(null) }
    var amountText by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(10.dp))
        Text("Budgets", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(ui.monthLabel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🎯 Overall monthly budget", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                editing = BUDGET_ALL
                                amountText = ui.overall?.let { "%.2f".format(it.limit / 100.0) } ?: ""
                            }) { Text(if (ui.overall == null) "Set" else "Edit") }
                        }
                        if (ui.overall != null) {
                            Spacer(Modifier.height(6.dp))
                            LimitProgress(used = ui.overall!!.spent, limit = ui.overall!!.limit)
                        } else {
                            Text("Not set — tap Set to add one", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item {
                Text("Per-category budgets", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            items(ui.rows, key = { it.category }) { row ->
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${catEmoji(row.category)}  ${catLabel(row.category)}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                editing = row.category
                                amountText = "%.2f".format(row.limit / 100.0)
                            }) { Text("Edit") }
                        }
                        Spacer(Modifier.height(6.dp))
                        LimitProgress(used = row.spent, limit = row.limit)
                    }
                }
            }

            item {
                OutlinedButton(onClick = { editing = "__new__"; amountText = "" }, modifier = Modifier.fillMaxWidth()) {
                    Text("➕ Add category budget")
                }
                Spacer(Modifier.height(8.dp))
                InfoNote("Budgets track this calendar month. Bars turn yellow at 80% and red when you pass the limit.")
                Spacer(Modifier.height(90.dp))
            }
        }
    }

    editing?.let { cat ->
        if (cat == "__new__") {
            NewBudgetDialog(
                existing = ui.rows.map { it.category },
                onDismiss = { editing = null },
                onSave = { category, cents -> vm.setBudget(category, cents); editing = null }
            )
        } else {
            AlertDialog(
                onDismissRequest = { editing = null },
                confirmButton = {
                    TextButton(onClick = {
                        val cents = parseToCents(amountText)
                        if (cents != null) { vm.setBudget(cat, cents); editing = null }
                    }) { Text("Save") }
                },
                dismissButton = {
                    Row {
                        TextButton(onClick = { vm.setBudget(cat, 0); editing = null }) { Text("Remove", color = MaterialTheme.colorScheme.error) }
                        TextButton(onClick = { editing = null }) { Text("Cancel") }
                    }
                },
                title = { Text("${catEmoji(cat)} ${catLabel(cat)} budget") },
                text = {
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it },
                        label = { Text("Monthly limit") },
                        prefix = { Text("RM ") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true
                    )
                }
            )
        }
    }
}
